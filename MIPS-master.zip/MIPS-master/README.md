﻿# MIPS project to ORG-B subject
Projeto para a disciplina Organização de Computadores.

#Instruções Realizadas

- BNE Monociclo, Multiciclo e Pipeline;
- XORI Monociclo, Multiciclo e Pipeline;
- JAL Monociclo, Multiciclo e Pipeline;
- SRLV Monociclo, Multiciclo e Pipeline;

#Como executar
- Tenha Logisim;
- Abra o arquivo .cir com logisim;
- Vá em simular->pulso habilitado;
